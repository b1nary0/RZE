# [Brofiler: C++ Profiler For Games](http://brofiler.com)
## [Tutorial](https://github.com/bombomby/brofiler/wiki)   
![](http://brofiler.com/images/screenshots/Screen0.png)
[![Analytics](https://ga-beacon.appspot.com/UA-59213040-1/brofiler/readme)](https://github.com/bombomby/brofiler)
