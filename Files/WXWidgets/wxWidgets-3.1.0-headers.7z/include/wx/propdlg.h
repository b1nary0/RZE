/////////////////////////////////////////////////////////////////////////////
// Name:        wx/propdlg.h
// Purpose:     wxPropertySheetDialog base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_PROPDLG_H_BASE_
#define _WX_PROPDLG_H_BASE_

#include "wx/generic/propdlg.h"

#endif
    // _WX_PROPDLG_H_BASE_

