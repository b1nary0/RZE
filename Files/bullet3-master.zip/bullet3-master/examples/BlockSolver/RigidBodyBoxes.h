#ifndef BLOCKSOLVER_RIGIDBODYBOXES_H_
#define BLOCKSOLVER_RIGIDBODYBOXES_H_

class CommonExampleInterface* RigidBodyBoxesCreateFunc(struct CommonExampleOptions& options);

#endif  //BLOCKSOLVER_RIGIDBODYBOXES_H_
